代码来自于GitHub仓库 [team-approx-bayes/fromp](https://github.com/team-approx-bayes/fromp) 
该仓库包含了NeurIPS 2020论文"Continual Deep Learning by Functional Regularisation of Memorable Past" by Pan et al.的代码。该仓库专注于使用功能正则化进行持续学习，以避免忘记过去的信息。以下是仓库中关键组件的概览：

1. **[models.py](https://github.com/team-approx-bayes/fromp/blob/main/models.py)**：定义了实验中使用的各种神经网络模型，包括`MLP`（多层感知器）、`SplitMLP`和`CifarNet`。

2. **[opt_fromp.py](https://github.com/team-approx-bayes/fromp/blob/main/opt_fromp.py)**：包含FROMP优化器的实现，这是一个基于PyTorch的Adam优化器构建的PyTorch优化器，具有FROMP功能正则化的特定添加。

3. 训练脚本：
   - **[train_cifar.py](https://github.com/team-approx-bayes/fromp/blob/main/train_cifar.py)**：用于在CIFAR数据集上进行训练的脚本。
   - **[train_permutedmnist.py](https://github.com/team-approx-bayes/fromp/blob/main/train_permutedmnist.py)**：用于在排列MNIST数据集上进行训练的脚本。
   - **[train_splitmnist.py](https://github.com/team-approx-bayes/fromp/blob/main/train_splitmnist.py)**：用于在分割MNIST数据集上进行训练的脚本。
   - **[train_toydata.py](https://github.com/team-approx-bayes/fromp/blob/main/train_toydata.py)**：用于在玩具数据集上进行训练的脚本。

4. 主要脚本：
   - **[main_cifar.py](https://github.com/team-approx-bayes/fromp/blob/main/main_cifar.py)**：用于在CIFAR数据集上运行实验的主脚本。
   - **[main_permutedmnist.py](https://github.com/team-approx-bayes/fromp/blob/main/main_permutedmnist.py)**：用于在排列MNIST数据集上运行实验的主脚本。
   - **[main_splitmnist.py](https://github.com/team-approx-bayes/fromp/blob/main/main_splitmnist.py)**：用于在分割MNIST数据集上运行实验的主脚本。
   - **[main_toydata.py](https://github.com/team-approx-bayes/fromp/blob/main/main_toydata.py)**：用于在玩具数据集上运行实验的主脚本。

5. **[datasets.py](https://github.com/team-approx-bayes/fromp/blob/main/datasets.py)**：包含不同实验的数据集加载器和生成器。

6. **[utils.py](https://github.com/team-approx-bayes/fromp/blob/main/utils.py)**：提供跨不同脚本使用的实用函数。


数据集

**Toy Dataset：**一个二维的二分类数据集，使用了一个小型的多层感知器（MLP）进行实验。这个数据集用于展示权重规范化方法的脆弱性和不一致性，并测试了FROMP在不同难度的玩具数据集上的性能。

**排列MNIST（Permuted MNIST）：**Permuted MNIST由一系列任务组成，每个任务都应用了对整个MNIST数据集像素的固定排列。这是一个常见的持续学习实验设置，用于测试模型在处理不同任务时的灵活性和记忆保持能力。

**分割MNIST（Split MNIST）：**这个数据集将原始的MNIST数据集分割成多个子集，每个子集代表一个不同的任务。这种设置用于评估模型在连续学习不同但相关任务时的性能。

**分割CIFAR（Split CIFAR）：**CIFAR-10和CIFAR-100数据集的分割版本，包含了多个任务，每个任务由CIFAR数据集中的不同类别组成。这个数据集用于评估模型在处理更复杂的图像识别任务时的性能。

res文件夹中保存了main_cifar.py, main_permutedmnist.py, main_splitmnist.py,  main_toydata.py的运行结果
| Benchmark | File | Average accuracy |
|---        |---   |---               |
| Split MNIST | ``main_splitmnist.py`` | 99.3% |
| Permuted MNIST | ``main_permutedmnist.py`` | 94.8% |
| Split CIFAR | ``main_cifar.py`` | 76.2% |
| Toy dataset | ``main_toydata.py`` | (Visualisation) |
